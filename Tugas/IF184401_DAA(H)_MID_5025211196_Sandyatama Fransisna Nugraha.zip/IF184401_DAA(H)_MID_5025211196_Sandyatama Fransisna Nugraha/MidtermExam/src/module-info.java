module MidtermExam {
	exports mytree;
	exports mid;
}